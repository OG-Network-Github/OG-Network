let display = document.querySelector(".display");

plus.addEventListener("click", () => {
  // display.innerText = perform(check());
  display.innerText = checkAndRemoveLast(display);
});
minus.addEventListener("click", () => {
  display.innerText = display.innerText + "-";
});
multi.addEventListener("click", () => {
  display.innerText = display.innerText + "*";
});
div.addEventListener("click", () => {
  display.innerText = display.innerText + "/";
});
clear.addEventListener("click", () => {
  display.innerText = "0";
});
clearall.addEventListener("click", () => {
  display.innerText = "0";
});
fraction.addEventListener("click", () => {
  display.innerText = "1/" + display.innerText;
});
square.addEventListener("click", () => {
  display.innerText = display.innerText + "**2";
});
root.addEventListener("click", () => {
  display.innerText = Math.sqrt(display.innerText);
});
backspace.addEventListener("click", () => {
  display.innerText = display.innerText.slice(0, -1);
});
solve.addEventListener("click", () => {
  display.innerText = result();
});
function result() {
  a = display.innerText;
  return eval(a);
}

let check = (() =>{
  b = display.innerText
  for ( i of b) {
    }
    if(i == "+","-","*","/"){
      alert("true")
      return "true"
    }
    else{
      alert("false")
      return "false"
    }
    }   //pass
);
function perform(mode) {
  console.log(check()) 
  if(mode == "false"){
    return display.innerText; 
  }
  else if(mode == "true"){
    return b.slice(0, -1); 
  }
  
}
function pro(params) {
   if(params.endswith("+")){
    alert("true")
   }
   else{
    alert("false")
   }
   console.log("done")
}
function checkAndRemoveLast(display) {
  // Check if display ends with "+"
  if (display.endsWith("+")) {
    // Remove the last character from the display string
    display = display.slice(0, -1);
    // Update the display element with the modified string
    document.querySelector(".display").innerText = display;
  }
  // Return the updated or unchanged display string
  return display;
}

